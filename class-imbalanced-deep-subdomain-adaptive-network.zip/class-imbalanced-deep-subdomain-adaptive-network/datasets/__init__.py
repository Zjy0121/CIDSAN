#!/usr/bin/python
# -*- coding:utf-8 -*-

from datasets.CWRU import CWRU
from datasets.SQI import SQI
# from datasets.sequence_aug import *
# from datasets.SequenceDatasets import dataset